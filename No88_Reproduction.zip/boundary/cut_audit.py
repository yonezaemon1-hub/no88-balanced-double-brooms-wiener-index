"""Supplementary same-assistant check: direct edge-cut evaluation of tight forests.
No import of author DP, proof bounds, or checker. Counts are marked diameter
representations (not counts of nonisomorphic unmarked trees). Standard library.
"""
from functools import lru_cache
from collections import Counter,deque

@lru_cache(None)
def forests(n, minimum=()):
    # Rooted trees are nested tuples; forest types sorted lexicographically.
    if n==0: return ((),)
    return tuple((r,)+tail for j in range(1,n+1) for r in roots(j) if r>=minimum
                 for tail in forests(n-j,r))
@lru_cache(None)
def roots(n):
    return forests(n-1)
@lru_cache(None)
def metrics(r):
    child=[metrics(t) for t in r]
    size=1+sum(x[0] for x in child)
    height=1+max((x[1] for x in child),default=0)
    # Each edge entering a branch vertex has subtree order equal to its size.
    cuts=(size,)+tuple(x for _,_,cc in child for x in cc)
    return size,height,cuts

def side_options(n,d,total,right):
    out=[]
    for f in forests(total):
        placements=Counter(); value=0
        for r in f:
            s,h,cuts=metrics(r)
            if 2*h>d: break
            placements[d-h if right else h]+=s
            value+=sum(x*(n-x) for x in cuts)
        else:
            out.append((tuple(placements.items()),value,all(r==() for r in f)))
    return out

def path_sum(n,d,lp,rp):
    pos=Counter(dict(lp));pos.update(dict(rp));prev=0;extra=0;value=0
    def S(x): return x*(x+1)//2
    def Q(x): return x*(x+1)*(2*x+1)//6
    for x,count in sorted(pos.items())+[(d,0)]:
        lo=prev+1+extra;hi=x+extra
        value+=n*(S(hi)-S(lo-1))-(Q(hi)-Q(lo-1))
        prev=x;extra+=count
    return value

def direct(n,d,k):
    m=(k+1)//2
    B=path_sum(n,d,((1,m),),((d-1,k-m),))+k*(n-1)
    best=None; rival=None;count=0
    for l in range(k+1):
        r=k-l
        for lp,lv,lleaf in side_options(n,d,l,False):
            for rp,rv,rleaf in side_options(n,d,r,True):
                w=lv+rv+path_sum(n,d,lp,rp);count+=1
                best=w if best is None else max(best,w)
                if not(lleaf and rleaf and abs(l-r)<=1):
                    rival=w if rival is None else max(rival,w)
    return B,best,rival,count

def bfs_witness(k,d):
    m=(k+1)//2;s=m//2+1
    def make(triple):
        adj=[[] for _ in range(d+1)]
        def edge(x,y): adj[x].append(y);adj[y].append(x)
        def add(parent):
            v=len(adj);adj.append([]);edge(parent,v);return v
        for i in range(d):edge(i,i+1)
        for _ in range(k-m):add(d-1)
        if triple:
            a=add(2)
            for _ in range(s-1):add(a)
            for _ in range(m-s):add(1)
        else:
            for _ in range(m):add(1)
        return adj
    def stats(g):
        W=dia=0
        for x in range(len(g)):
            ds=[-1]*len(g);ds[x]=0;q=deque([x])
            while q:
                v=q.popleft()
                for y in g[v]:
                    if ds[y]<0:ds[y]=ds[v]+1;q.append(y)
            W+=sum(ds);dia=max(dia,max(ds))
        leaf_neighbors={g[v][0] for v in range(len(g)) if len(g[v])==1}
        return len(g),dia,W//2,len(leaf_neighbors)
    a,b=stats(make(False)),stats(make(True))
    assert a[:3]==b[:3] and a[0]==d+k+1 and a[1]==d and a[3]==2 and b[3]==3,(k,d,a,b)

if __name__=='__main__':
    total=0
    for k in range(7,13):
        m=(k+1)//2;D=2*(m*m//4)+3+k%2
        for d in (D-1,D,D+1):
            B,best,rival,count=direct(d+k+1,d,k)
            assert (rival>=B if d==D-1 else best==B and rival<B),(k,d,B,best,rival)
            assert rival>=B-(d-D+1),(k,d,B,rival)
            total+=count
            print(f'k={k:2} d={d:2} B={B:6} max={best:6} nonB_gap={rival-B:2} marked={count}',flush=True)
        bfs_witness(k,D-1)
    print(f'PASS: {total} marked tight-forest representations; 18 boundary instances; 6 direct BFS tie witnesses')
