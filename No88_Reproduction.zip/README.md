# No.88 — reproducibility assets (v1.0)

Ryutaro Yonezu | 26 November 2026 | All rights reserved.

NOT HUMAN PEER REVIEWED / NOVELTY INCONCLUSIVE / REFERENCES PARTIAL.
The threshold proof is analytic with finite elementary cases; the scripts are corroborative, not proof premises. The two frozen mathematical texts retain their historical headings/status (including pre-audit status). The publication manuscript and VERIFICATION.md give the current status. No independent audit code or private archives are redistributed.

Requirements: Python 3.10+; NetworkX (tested 3.6.1 on Windows) for the algorithm tests. All threshold and boundary scripts use the standard library. Run from the extracted archive root:

```text
python -B run_reproduce.py
```

The runner verifies payload hashes and compares six outputs against the frozen baseline logs, ignoring only elapsed-time lines. A nonzero exit, hash mismatch or output mismatch is a failure. No network access is used. Install NetworkX separately if needed. The independent AI auditor's larger checks are not part of this public replay.
