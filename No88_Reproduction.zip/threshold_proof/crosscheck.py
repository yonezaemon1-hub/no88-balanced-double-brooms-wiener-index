"""Literal scan of all branch size/height/imbalance inputs, including parity-transfer cases."""
from fractions import Fraction as F
from math import comb
from v12_check import loss
N=0; minmargin=None
for k in range(7,15):
    m=(k+1)//2;eps=2*m-k;D=2*(m*m//4)+3+eps
    peak=None;count=0
    for s in range(2,k+1):
        for H in range(1,s):
            h=H+1;d=max(D,2*h);q=d-2;c=d+k
            u=s*(H*(H+2+2*m)+1-h*s)-c*H*h//2-2*comb(h,3)-loss(s,H,c)
            for t in range(max(0,s-m),k-m+1):
                I=t*(t+eps)
                budget=q*I if s>m and H>=k-s-1 else F(s*q*I,m+t)
                value=u+2*H*s*t-budget
                assert value<0,(k,s,H,t,value)
                peak=value if peak is None else max(peak,value)
                count+=1
    print(f'k={k} inputs={count} max={peak}')
    N+=count
print(f'PASS: {N} literal branch/imbalance inputs (same inequality, not an independent mathematical audit)')
