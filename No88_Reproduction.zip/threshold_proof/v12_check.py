"""Exact checks for v0.12; no tree/partition enumeration or Wiener-index DP."""
from fractions import Fraction as F
from math import comb


def g(q, eps, H, m, t):
    return 2*H*t-F(q*t*(t+eps),m+t)


def gpeak(q, eps, H, m, l, r):
    # Forward differences decrease: 2H-q+q*m*(m-eps)/((m+t)*(m+t+1)).
    lo,hi=l,r
    while lo<hi:
        t=(lo+hi)//2
        if 2*H-q+F(q*m*(m-eps),(m+t)*(m+t+1))>0:
            lo=t+1
        else:
            hi=t
    v=g(q,eps,H,m,lo)
    assert v==max(g(q,eps,H,m,t) for t in range(l,r+1))
    return v


def quadratic(a,b,c,l,r,integer=False):
    a,b,c,l,r=map(F,(a,b,c,l,r))
    assert a<0 and l<=r
    x=max(l,min(r,-b/(2*a)))
    if not integer:return a*x*x+b*x+c
    f=x.numerator//x.denominator
    pts={l,r,max(l,min(r,F(f))),max(l,min(r,F(f+1)))}
    v=max(a*t*t+b*t+c for t in pts)
    assert v==max(a*t*t+b*t+c for t in range(int(l),int(r)+1))
    return v


def loss(s,H,c):
    h=H+1;e=s-h;j=max(1,h-e);j1=max(1,h-2)
    J=e*(H-1)*(H+e+1)
    K=e*(j-1)*(2*h-j+e-1)
    K1=e*(j1-1)*(2*h-j1+e-1)
    assert c>=2*(s-1)
    return max(K,min(J,c+K1,max(2*c,K+2*(c-2*(s-1)))))


def test():
    N=0;Ns=0;rows=[]; details=[]
    for k in range(7,15):
        m=(k+1)//2;eps=2*m-k;D=2*(m*m//4)+3+eps;r=k-m
        D_even=D-eps
        coarse=[]; residual=[]; skip=[]; peaks=[]
        for H in range(2,k):
            h=H+1
            if eps and 2*h<=D_even:
                skip.append(H);continue
            d0=max(D,2*h);q=d0-2;c=d0+k
            assert q>=2*H and c>=2*(k-1)
            a=H*(H+2+2*m)+1; C=-c*H*h//2-2*comb(h,3)
            B=quadratic(-h,a+gpeak(q,eps,H,m,0,r),C,h,k)
            N+=1
            if B<0:
                coarse.append((H,B));continue
            residual.append((H,B)); rp=[]
            for s in range(h,k+1):
                l=max(0,s-m);u=-h*s*s+a*s+C-loss(s,H,c)
                full=(s>m and H>=k-s-1)
                if full:
                    val=quadratic(-q,2*H*s-q*eps,u,l,r,integer=True)
                    assert val==max(u+2*H*s*t-q*t*(t+eps) for t in range(l,r+1))
                else:
                    val=u+s*gpeak(q,eps,H,m,l,r)
                assert val<0,(k,H,s,val)
                rp.append(val);Ns+=1
            peaks.append((H,max(rp)))
        print(f'k={k} parity_transfer={skip} coarse_pass={len(coarse)} coarse_max={max((v for _,v in coarse),default="NA")} residual={[(H,str(v)) for H,v in residual]} refined_peaks={[(H,str(v)) for H,v in peaks]}')
        rows.append((k,skip,coarse,residual,peaks))
    print(f'PASS: {N} coarse height comparisons + {Ns} refined size comparisons = {N+Ns}; no exceptional branch types')
    assert (N,Ns)==(41,53)
    return rows

if __name__=='__main__': test()
