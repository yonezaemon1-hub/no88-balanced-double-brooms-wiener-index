# No.88 v0.13 — interval-inequality proof of the sharp threshold
Private candidate; Theorem 5 only. No changes to v0.8 Theorems 1–4. NOVELTY INCONCLUSIVE / REFERENCES PARTIAL / NOT HUMAN PEER REVIEWED / All rights reserved / PUBLICATION HOLD.

## Claim and scope
For k=n-d-1>=7, m=ceil(k/2), eps=2m-k, the least D>=3 such that the balanced double broom B is the unique Wiener-index maximizer up to isomorphism for every d>=D is
D=2 floor(m^2/4)+3+eps.
Sections 1, 2 and 4 are carried from v0.12. Section 3 replaces the finite size/height input checks with continuous-interval inequalities, explicit small-parameter algebraic cases, and a parity-transfer argument covering all heights. All polynomial identities, rational bounds and finite case distinctions are stated in the proof. No enumeration of candidate trees, branch sizes or imbalance inputs, or execution of code, is needed to verify the argument. This is an analytic proof candidate with finite elementary algebraic cases, NOT a single case-free inequality and NOT independently audited. The optional script checks the algebraic certificates and separately repeats the earlier literal scan as corroboration only.

## 1. Tight branches and exact comparison
Choose a diameter path 0,...,d. For any off-path component, let its size be s and height h measured from the path attachment (including the attachment edge). The feasible positions are exactly h<=x<=d-h: distances to the two endpoints give necessity; for distinct branches at x<=y, their cross distances are at most h_x+y-x+h_y<=d, and distances within a branch are at most 2h<=d. The original path preserves diameter d. Holding all other components fixed, the x-dependent part of W is s(x^2-dx) plus a nonnegative sum of multiples of |x-y| and a constant. This is strictly convex. Hence every maximizer is tight: each component is attached at h or d-h. Assign the components left/right accordingly (arbitrarily for a middle attachment). Distinct components sharing an attachment are kept distinct.

Write H_i=h_i-1, a_v=h_i-depth(v) (depth from path), A_i=sum a_v, A=sum A_i. A deepest path within component i has h_i vertices and gives A_i>=H_i(H_i+1)/2. A component with H=0 is a single leaf. Let L+R=k, and I=floor(k^2/4)-LR. Compare with the possibly unbalanced broom B_{L,R}, with L and R extra leaves at positions 1 and d-1. The excess of the distances from v to the diameter path over those from a broom leaf is H_i(H_i+3)-(d+1)a_v, by summing |x-j|+depth(v) over j=0,...,d. For same-side pairs in distinct branches the excess is 2max(H_i,H_j)-a_v-a_w; for a pair in the same branch the excess is 2H_i-a_v-a_w-2lca(v,w), where lca is depth of their lowest common ancestor measured from the attachment. For opposite sides the excess is -a_v-a_w. Thus W(T)-W(B_{L,R})=P-(d+k)A, where P is the sum of s_i H_i(H_i+3) and twice the sum of max(H_i,H_j) over all same-side pairs (including H_i for within-branch pairs), minus twice the within-branch LCA sum. W(B_{L,R})-W(B)=-(d-2)I, by comparing same-side and cross-side leaf pairs.

For a side of size M let
P_i(M)=s_i[H_i(H_i+2+2M)+1-(H_i+1)s_i].
Using max(H_i,H_j)<=H_i+H_j and lca>=1 gives
W(T)-W(B) <= -(d-2)I + sum_i [P_i(M_i)-(d+k)A_i].   (1)
For H=0, s=1 and P_i=0. For later use the exact improvement to (1) is to subtract 2 min(H_i,H_j)s_i s_j for each pair of distinct branches on the same side, and 2(lca(v,w)-1) for each within-branch pair.

## 2. Symbolic proof for m>=8
Put Q=2 floor((m+2)^2/4), c0=Q+1, D=Q-k+1. This agrees with the displayed D; c0 >= (m+2)^2/2, and d-2>=D-2>=m^2/2 for d>=D. Write c=d+k>=c0.

For balanced sides or a light side M<=m, we use t=0 and budget share zero; P_i(M)<=P_i(m). Otherwise the heavy side has M=m+t, 1<=t<=k-m<=m, and I=t(t+eps)>=t^2. Assign to its component of size s the share s(d-2)I/M of the imbalance penalty. Its per-vertex budget b=(d-2)I/M satisfies b>=m t^2/4, since M<=2m. When t=1 the stronger b>=m^2/[2(m+1)] holds. Also P_i(M)=P_i(m)+2Hst. It suffices to show, for H>=1,
P_i(m)+s(2Ht-b) < c A_i.   (2)
Here for t=0 take b=0. For H=0 the contribution after its budget share is nonpositive (strict on a heavy side).

H=1: P_i(m)=2s(m+2-s)<=Q, A_i>=1. If t>=1, 2t-b<=2t-m t^2/4<=0; also true at t=0. Thus (2) holds with gap at least 1.

H=2: for t=1, 4t-b<=4-32/9=4/9; for t>=2, 4t-b<=4t-2t^2<=0. At t=0 it is zero. Therefore the LHS of (2) is at most s(4m+9+4/9-3s) <= (4m+9+4/9)^2/12. The ratio (4m+9+4/9)/(m+2) is decreasing for m>=8 and at 8 is 373/90, whose square is less than 18. The last bound is strictly below 3(m+2)^2/2<=c A_i.

H>=3: completing the square gives 2Ht-m t^2/4<=4H^2/m for any real t (and the bound holds at t=0). The LHS of (2) is thus at most
s[a-(H+1)s], a=2Hm+H(H+2)+1+4H^2/m.   (3)
For 3<=H<=17, a/(m+2)=2H+[H(H-2)+1+4H^2/m]/(m+2) is decreasing in m>=8. At m=8, a=(3H^2+36H+2)/2. For the full real interval 3<=H<=17,
400H(H+1)^2-(3H^2+36H+2)^2>0.
Indeed, with H=3+14u, 0<=u<=1, its degree-four Bernstein coefficients are 431,4645,91453/3,130085,9839, all positive. These coefficients can be verified by expanding sum_{j=0}^4 b_j binom(4,j)u^j(1-u)^{4-j}. Hence a^2 < (m+2)^2 H(H+1)^2 and (3) <= a^2/[4(H+1)] < (m+2)^2 H(H+1)/4 <= c A_i.

H>=18: s>=H+1 and s<=2m imply m>=10. Separate the H^2 s term and use s<=2m:
(3) <= (2m+8)H^2 + [2H(m+1)+1]^2/[4(H+1)] <= (2m+8)H^2 + H^2(m+2)^2/(H+1).
Subtracting this from c A_i leaves at least H^2 times
(m+2)^2[(H+1)/(4H)-1/(H+1)]-2m-8.
The bracket is increasing for H>=1 (its derivative is 1/(H+1)^2-1/(4H^2)>=0); at H=18 it is 289/1368. For m>=10, writing m=10+x, the lower bound (289/1368)(12+x)^2-28-2x has positive constant and linear coefficients and positive quadratic coefficient. This proves (2).

In a balanced arrangement every nonleaf branch gives strict loss; all leaves give B. In an unbalanced arrangement the budget shares sum to (d-2)I and every heavy-side component gives strict loss after its share (including single leaves); light-side components contribute at most zero. Consequently all tight non-B trees are strictly inferior for d>=D. Every maximizer is tight, so this proves uniqueness.

## 3. Small range: a continuous-interval proof
The inherited Section 2 covers m>=8, so consider 4<=m<=7. Write k=2m-eps, D=2 floor(m^2/4)+3+eps. For each H>=1 put h=H+1, d0=max(D,2h), q=d0-2, c=d0+k. These are lower bounds on the actual d-2 and d+k for a feasible branch. In particular c>=2(k-1), since c>=2 floor(m^2/4)+2m+3 and 2 floor(m^2/4)>=2m-5 for m>=4. Use M=m as an upper bound on light and balanced side sizes, and M=m+t for the heavy side, 1<=t<=k-m. The imbalance is I=t(t+eps).

### 3.1 Uniform height-one bound
In the notation of Section 1, H=1 gives P_i(m)=2s(m+2-s)<=Q. With proportional budget s q I/(m+t), the extra per-vertex term is g=2t-q t(t+eps)/(m+t). For t>=1, q(t+eps)/(m+t)>=q/(m+1)>=2 if m>=5; indeed q>=2 floor(m^2/4)+1 >=2(m+1) for m>=5. For m=4, eps=1 the same quotient is at least 4. For m=4, eps=0, t>=2 it is at least 3. Thus g<=0 in all these cases and also at t=0. Since c>=Q+1 and A>=1, there is strict loss. In the remaining m=4, eps=0, t=1 case, g<=1/5 and the real quadratic maximum of s(12+1/5-2s) is 3721/200<19=c. This proves the desired inequality for every H=1 branch, using proportional charging. Full charging, if chosen, only strengthens the bound. No size or imbalance enumeration is needed.

### 3.2 Uniform extra-vertex deficit lemma (all H>=1)
Select a deepest path of h off-path vertices in a branch of size s=h+e. Let E be the sum of deficits h-depth(v) over its e extra vertices, so A=Hh/2+E. The mandatory within-path LCA loss beyond lca>=1 is 2 binom(h,3). Let L_extra denote the remaining within-branch LCA loss beyond lca>=1, over pairs involving at least one extra vertex. For j in [1,h], define

K(j)=e(j-1)(2h-j+e-1), j0=max(1,h-e), j1=max(1,h-2),
J=e(H-1)(H+e+1), K0=K(j0), K1=K(j1).

If every extra vertex meets the chosen path at depth at least j, every extra/path pair has LCA depth at least min(i,j) for path depth i, and every extra/extra pair has LCA depth at least j. Summing twice the excess over depth 1 gives K(j).

For arbitrary E, each extra vertex v of deficit a meets the path at depth at least max(1,h-e-a), because at most e vertices on its path lie outside the chosen path. Consequently L_extra>=K0-2(s-1)E: an extra/path pair's loss relative to the j0 bound is at most 2a, and an extra/extra pair's loss is at most 2(a+a'). Since c>=2(s-1), cE+L_extra>=K0.

If E=0, all extra vertices have depth h and their parents are on the path at depth h-1. Hence L_extra=J. If E=1, the only extra vertex with positive deficit has depth h-1; all others have depth h. A depth-(h-1) extra vertex must attach directly to the path at depth h-2, and a depth-h extra vertex either attaches directly to the path or has that unique extra vertex as parent. (When h=2 and E=1 is infeasible, the implication is vacuous.) Thus all extra vertices meet the path at depth at least j1 and cE+L_extra>=c+K1. If E>=2, L_extra>=0 and the earlier inequality gives cE+L_extra>=max(2c,K0+2(c-2(s-1))). Combining these disjoint cases with the bound K0 valid for all E yields the uniform lower bound

Z(s,H,c)=max(K0,min(J,c+K1,max(2c,K0+2(c-2(s-1))))) <= cE+L_extra. (4)

It is nondecreasing in c and is valid for every branch shape, including e=0. This removes all special LCA bounds and all exceptional-branch types from v0.11.

### 3.3 Two budget rules
Let a=H(H+2+2m)+1, C=-cHh/2-2 binom(h,3), u=-h s^2+a s+C-Z(s,H,c). By (1) and (4), this branch's contribution before charging imbalance is at most u+2Hst. For light sides use t=0 (P_i(M)<=P_i(m)). A leaf has zero contribution before budget. For heavy sides use either:

- Proportional rule: charge s q I/(m+t), giving u+s g_H(t), where g_H(t)=2Ht-q t(t+eps)/(m+t).
- Large branch rule: if s>m and H>=k-s-1, charge the whole q I, giving u+2Hst-qI.

There is at most one branch eligible for the large branch rule. If it exists, the remaining branches on its side have total M-s<=m-1 and each has height parameter J'<=k-s-1<=H. The exact cross correction from the large branch to another branch of size v is 2J'sv. Subtracting it changes that branch's P_i(M) precisely to P_i(M-s), so all remaining branches are bounded by the light-side inequality with no additional charge. Other cross corrections can only help. Thus it suffices to prove strict negativity for all nonleaf branches under the specified rule (large if eligible, otherwise proportional), including the light-side case t=0,s<=m. If no large branch is eligible, all proportional charges sum to the imbalance cost qI; single leaves also lose strictly when t>0. When d>d0 for some branches, the actual penalty is (d-2)I, and these comparisons using smaller q remain sufficient: allocate the actual penalty first and bound each share by its corresponding lower q. With a large branch use the actual entire penalty and bound it by the corresponding qI. For t=0 only balanced leaves give equality. Hence strict local inequalities on the indicated domains imply global strict dominance.

### 3.4 Transfer every odd case from the even case
Fix m. Denote by q_e,c_e the lower costs for k_e=2m, and q_o,c_o those for k_o=2m-1. The quantities P_i(m), s, H, A and the actual LCA correction are identical. The admissible odd ranges for s,t are subsets of the even ranges. If 2h<=D_e, then c_o=c_e and q_o=q_e+1; the odd imbalance t(t+1) is at least t^2. An even full-charge eligible branch remains eligible in the odd case, and switching from a proportional charge to a full charge can only improve a bound. Thus the strict even local inequalities transfer.

If 2h>D_e, then c_o>=c_e-1 and q_o>=q_e=2h-2=2H. Since h is integral, h>=floor(m^2/4)+2>=4m/3 for m>=4 (use floor(m^2/4)>=(m^2-1)/4, and the resulting quadratic is positive and increasing from m=4). In particular h>m. Such a branch is heavy and s>=h>m; it is full-charge eligible in BOTH cases because h+s>=2m. The actual deficit of the branch satisfies

A <= Hh/2+(s-h)H = Hs-Hh/2,

by separating its deepest path from the other vertices. Since t>=s-m,

q_e t >= 2H(s-m) >= Hs-Hh/2 >= A,

where the middle inequality follows from s>=h>=4m/3. In the odd case the extra full charge q_e t therefore compensates for the possible reduction of one in c. Compare the actual local expression with its even counterpart BEFORE replacing the deficits and LCA by lower bounds. The odd expression is no larger than the even expression. The even proof covers all such branches, including the larger even admissible domain. This transfers all heights, not only those below D_e/2.

It remains to prove the even cases. In Sections 3.5–3.8 set k=2m, eps=0. The height-one proof of 3.1 already handles these.

### 3.5 A real bound for the imbalance gain
For t in [0,m], write g(t)=2Ht-q t^2/(m+t). For any fixed t, completing the square yields g(t)<=H^2(m+t)/q<=2mH^2/q. If q>2H and g(t)>0, then (q-2H)t<2Hm and m+t<mq/(q-2H), so g(t)<=mH^2/(q-2H); when g(t)<=0 the same upper bound is automatic. Both bounds remain true for real t. Also any G>=0 with q>2H and

(G-2Hm)^2-4(q-2H)Gm<=0

bounds g(t) for every real t>=0: multiply G-g(t) by m+t and complete the square. For a full-charge branch, for every real t,

2Hst-qt^2 <= H^2 s^2/q.

Thus the relaxed inequalities below prove strict loss simultaneously for entire real intervals, without searching integer t.

### 3.6 The even cases m=6,7, uniformly in height
Here q>=q0=2 floor(m^2/4)+1, c>=c0=q0+2+2m. Use q0=19, c0=33 for m=6, and q0=25, c0=41 for m=7. The full charge is at least the proportional charge on the feasible domain s<=m+t; hence a proportional bound suffices for both. Dropping Z but retaining the mandatory path LCA loss, the local expression is at most

-hs^2+[H(H+2+2m)+1+G]s-c0 Hh/2-Hh(H-1)/3.

Its maximum over all real s is negative if

P(H)=2c0 H(H+1)^2+(4/3)H(H+1)^2(H-1)-[H(H+2+2m)+1+G]^2>0.

For H=2 take G=3/2 in both cases. The discriminants in Section 3.5 are respectively -135/4 and -719/4, and P(2) is respectively 87/4 and 71/4, so the bound is strict.

For H>=3 use these continuous height intervals and G=r H^2:

|m|H interval [l,r0]|r|Degree-four Bernstein coefficients of P(l+(r0-l)u)|
|---|---|---|---|
|6|[3,4]|6/11|6940/121,35504/363,167107/1089,164899/726,38799/121|
|6|[5,11]|12/19|123864/361,291744/361,582724/361,900792/361,528288/361|
|7|[3,13]|14/25|56224/625,1355912/1875,21209356/5625,26783792/1875,16447144/625|

In the first row q0-2H>=11, and the other two rows use the first bound of 3.5. Every coefficient is positive. By the identity P(l+(r0-l)u)=sum_{j=0}^4 b_j binom(4,j)u^j(1-u)^(4-j), these polynomial inequalities hold throughout the respective real intervals (0<=u<=1). The intervals cover all admissible integer heights H>=3. No individual height or size check is needed for m=6,7.

### 3.7 The even cases m=4,5: large heights
For m=4 take H>=5; for m=5 take H>=7. In these ranges s=h+e<=2m implies 0<=e<=H/2. All branches are full-charge eligible, since h>m and h+s>=2m. Here K0=e(H-e)(H+2e) >= H^2 e, so Z>=H^2 e. Use q>=2H, c>=2h+2m, and the full-charge inequality of 3.5. The upper bound reduces by direct expansion to

-(H+2)e^2/2 + b(H)e + C(H),
b(H)=2Hm-H-1-H^2,
C(H)=H[-5H^2+6H(m-1)+6m-1]/6.

For m=4,H=5+x (x>=0), b=9-3x-x^2 and C=-10-(86/3)x-(19/2)x^2-(5/6)x^3. For m=5,H=7+x, b=13-5x-x^2 and C=-56-(185/3)x-(27/2)x^2-(5/6)x^3. Thus b<=9 or 13 and C<=-10 or -56 respectively, and (H+2)/2>=7/2 or 9/2. Since e>=0, completing the square gives the strictly negative bounds -10+81/14=-59/14 and -56+169/18=-839/18. This settles the entire large-height intervals without individual height comparisons.

### 3.8 Remaining low heights: interval certificates
All remaining even cases are m=4,H in {2,3,4}, or m=5,H in {2,3,4,5,6}. We prove a finite collection of elementary inequalities on REAL size intervals, not a list of integer size/imbalance tests. Here h=H+1; for m=4 all remaining heights have q=9,c=19, and for m=5 all have q=13,c=25.

On a size interval [l,r] put e_min=l-h and E_max=r-h. A useful linear lower bound for (4) is Z>=alpha e, where alpha=0 if E_max=0 and otherwise

alpha=max(0,min(H^2,(H-E_max)(H+2E_max)), min((H-1)(h+e_min), c/E_max+(j1-1)(2h-j1+e_min-1),2c/E_max)),

with j1=max(1,h-2). To verify this bound, first K0>=0 and for 0<e<=H, K0/e=(H-e)(H+2e), a concave quadratic whose minimum over [0,E_max] is bounded below by the smaller endpoint value. If E_max>H the endpoint value is negative and K0>=0 suffices. Second, from (4), Z>=min(J,c+K1,2c); divide by e>0, use e>=e_min and e<=E_max, and take the minimum of the resulting lower bounds. The case e=0 is immediate. This derivation uses no shape enumeration. In particular the displayed alpha is valid for every integer size in the interval and its formula is also valid under the real extension of Z.

For proportional branches the integer size domain is contained in the real interval [h,max(m,2m-H-2)] (empty if lower endpoint exceeds the upper). For full-charge branches it is contained in [max(h,m+1,2m-H-1),2m]. These domains follow directly from the eligibility rule in 3.3; full and proportional are used according to that rule.

Set a=H(H+2+2m)+1, C=-cHh/2-2 binom(h,3). For proportional branches use the G values shown below. Their discriminants in 3.5 are, in order of the proportional rows, -71/4,-639/400,-36,-75,-100, so each G is valid for all real t>=0. For full-charge branches use 3.5 directly. The local upper bounds are the following quadratics in the size variable x, throughout the indicated closed intervals:

Q_P(x)=-h x^2+(a+G-alpha)x+C+alpha h,
Q_F(x)=(-h+H^2/q)x^2+(a-alpha)x+C+alpha h.

|m|H|rule|real interval|alpha|G (P only)|Q(x)|max over interval|
|---|---|---|---|---|---|---|---|
|4|2|P|[3,4]|4|5/2|-3x^2+47x/2-47|-47/48|
|4|2|F|[5,8]|19/5|–|-23x^2/9+106x/5-238/5|-247/45|
|4|3|P|[4,4]|0|129/20|-4x^2+929x/20-122|-1/5|
|4|3|F|[5,8]|19/2|–|-3x^2+61x/2-84|-311/48|
|5|2|P|[3,6]|3|2|-3x^2+28x-68|-8/3|
|5|2|F|[7,10]|25/7|–|-35x^2/13+178x/7-464/7|-1839/91|
|5|3|P|[4,5]|9|5|-4x^2+42x-122|-12|
|5|3|F|[6,10]|25/3|–|-43x^2/13+113x/3-374/3|-692/39|
|5|4|P|[5,5]|0|10|-5x^2+75x-270|-20|
|5|4|F|[6,10]|10|–|-49x^2/13+55x-220|-3795/196|
|5|5|F|[6,10]|13|–|-53x^2/13+73x-337|-2167/212|
|5|6|F|[7,10]|36|–|-55x^2/13+73x-343|-6183/220|

The last column follows in every row by completing the square, with the vertex clipped to the displayed closed interval. These explicit elementary inequalities establish strict negativity without evaluating each integer size or imbalance. For two proportional domains only a singleton size is admissible; those are ordinary boundary cases of the same formula.

The remaining low-height case is m=4,H=4. Here h=5,s=5+e, 0<=e<=3, and only full charging is possible. The upper bound before subtracting Z is

U(e)=-29(5+e)^2/9+57(5+e)-210.

For 0<=e<=2, use Z>=K0=e(4-e)(4+2e). The polynomial K0-U=-2e^3+65e^2/9-79e/9+50/9 is strictly positive on this full interval: in the degree-three Bernstein basis its coefficients on [0,1] are 50/9,71/27,19/9,2, and on [1,2] are 2,17/9,59/27,8/9, all positive. For 2<=e<=3, U is increasing and U(3)=358/9<40. Meanwhile J=3e(5+e)>=42 and c+K1=19+2e(6+e)>=51. The expression K0+2(c-2(s-1))=K0+22-4e is concave on [2,3] and its endpoints are 46 and 40. Thus the third term in the minimum in (4) is at least 40, giving Z>=40. Hence U-Z<0 throughout this interval too.

This exhausts the small even parameter range by explicit inequalities, and Section 3.4 transfers every odd case. Section 3.3 then gives strict global dominance over all tight non-B trees. The strict loss of nontrivial branches and of unbalanced leaf-only arrangements proves uniqueness, since every maximizer is tight. No program-generated finite integer certificate is a premise of the proof. The ordinary finite algebraic cases, interval endpoint evaluations and coefficient identities remain part of the proof; no claim of a case-free proof is made.

## 4. Sharpness
At d=D-1, take L=m and R=k-m, with a height-2 branch of size s=floor(m/2)+1 at position 2 (one root and s-1 leaves), the remaining m-s extra leaves at position 1, and R extra leaves at d-1. This is tight and retains diameter d. Since d>=10 for k>=7, the three distinct vertices adjacent to leaves (including path positions 1,d-1) certify that this is not B. Here A=1, I=0, and P=2s(m+2-s)=Q, exactly (all other branches are single leaves, LCA within the branch is 1). W(T)-W(B)=Q-k-d=0. Thus B is not uniquely maximizing at d=D-1, even if some third tree is strictly better. Combined with strict dominance at all d>=D, this proves the claimed persistent threshold. No assertion that B is globally maximizing at d=D-1 is needed.

## 5. Verification and status
The proof is self-contained relative to the elementary identities and tight-branch reduction it explicitly proves. The optional Python checker re-derives the displayed rational interval certificates, and separately corroborates the original small-range inequality by literal scanning; the latter is not used as a proof premise. No historical novelty or publication status is upgraded. The prior external reviews covered Theorems 1–4, not Theorem 5. Independent audit and Windows reproduction of this new version remain pending. Related literature: Borovicanin et al., arXiv:2507.17885v2, including the tight-branch condition and triple-broom obstruction; see v0.8/v0.12 for the remaining related-work record. No additional literature search was performed in this revision.
