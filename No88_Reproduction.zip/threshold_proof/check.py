"""Optional exact verification of the written interval identities; standard library only."""
from fractions import Fraction as F
from math import comb

def add(a,b):
    return [(a[i] if i<len(a) else 0)+(b[i] if i<len(b) else 0) for i in range(max(len(a),len(b)))]
def scale(a,c): return [c*x for x in a]
def mul(a,b):
    r=[0]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b):r[i+j]+=x*y
    return r
def sub(a,b):return add(a,scale(b,-1))
def bern(p,l,r):
    n=len(p)-1
    v=[sum(p[i]*comb(i,j)*l**(i-j)*(r-l)**j for i in range(j,n+1)) for j in range(n+1)]
    return [sum(F(v[i])*F(comb(j,i),comb(n,i)) for i in range(j+1)) for j in range(n+1)]
def peak(A,B,C,l,r):
    assert A<0 and l<=r
    x=max(F(l),min(F(r),-F(B)/(2*A)))
    return A*x*x+B*x+C

def disc(m,H,q,G):return (G-2*H*m)**2-4*(q-2*H)*G*m

def P(m,c,r):
    H=[0,1];h=[1,1]
    return sub(add(scale(mul(H,mul(h,h)),2*c),scale(mul(mul(H,mul(h,h)),[-1,1]),F(4,3))),mul([1,2+2*m,1+r],[1,2+2*m,1+r]))

for m,q,c,d0,p0 in [(6,19,33,F(-135,4),F(87,4)),(7,25,41,F(-719,4),F(71,4))]:
    H=2;G=F(3,2);a=H*(H+2+2*m)+1+G;h=H+1
    assert disc(m,H,q,G)==d0<0
    assert 2*c*H*h*h+F(4,3)*H*h*h*(H-1)-a*a==p0>0
    print('H=2 real bound',m,p0)
for m,c,l,r,R,expected in [
    (6,33,3,4,F(6,11),['6940/121','35504/363','167107/1089','164899/726','38799/121']),
    (6,33,5,11,F(12,19),['123864/361','291744/361','582724/361','900792/361','528288/361']),
    (7,41,3,13,F(14,25),['56224/625','1355912/1875','21209356/5625','26783792/1875','16447144/625'])]:
    b=bern(P(m,c,R),l,r);assert b==list(map(F,expected)) and min(b)>0
    print('Bernstein height interval',m,l,r,'min coefficient',min(b))
for m,H0,B0,C0,expected in [(4,5,9,-10,['-10','-86/3','-19/2','-5/6']), (5,7,13,-56,['-56','-185/3','-27/2','-5/6'])]:
    H=[H0,1];Hp=mul(H,H);b=sub(sub(scale(H,2*m-1),[1]),Hp)
    C=scale(mul(H,add(add(scale(Hp,-5),scale(H,6*(m-1))),[6*m-1])),F(1,6))
    assert b[0]==B0 and max(b[1:])<0
    assert C==list(map(F,expected)) and max(C[1:])<0
    v=C0+F(B0*B0,2*(H0+2));assert v<0
    print('large height interval',m,H0,v)
rows=[(4,2,'P',3,4,'4','5/2','-47/48'),(4,2,'F',5,8,'19/5','0','-247/45'),(4,3,'P',4,4,'0','129/20','-1/5'),(4,3,'F',5,8,'19/2','0','-311/48'),(5,2,'P',3,6,'3','2','-8/3'),(5,2,'F',7,10,'25/7','0','-1839/91'),(5,3,'P',4,5,'9','5','-12'),(5,3,'F',6,10,'25/3','0','-692/39'),(5,4,'P',5,5,'0','10','-20'),(5,4,'F',6,10,'10','0','-3795/196'),(5,5,'F',6,10,'13','0','-2167/212'),(5,6,'F',7,10,'36','0','-6183/220')]
for m,H,rule,l,r,alpha,G,expect in rows:
    alpha,G,expect=map(F,(alpha,G,expect));q=2*(m*m//4)+1;c=q+2+2*m;h=H+1;lo=l-h;E=r-h;j=max(1,h-2)
    alpha2=max(0,min(H*H,(H-E)*(H+2*E)),min((H-1)*(h+lo),F(c,E)+(j-1)*(2*h-j+lo-1),F(2*c,E))) if E else 0
    assert alpha==alpha2
    if rule=='P':
        assert (l,r)==(h,max(m,2*m-H-2));assert disc(m,H,q,G)<0
        A=-h
    else:
        assert (l,r)==(max(h,m+1,2*m-H-1),2*m);A=-h+F(H*H,q)
    B=H*(H+2+2*m)+1+G-alpha;C=-F(c*H*h,2)-2*comb(h,3)+alpha*h
    v=peak(A,B,C,l,r);assert v==expect<0
    print('size interval',m,H,rule,l,r,'maximum',v)
# Last low-height real interval: K0-U, in ascending coefficient order.
p=[F(50,9),F(-79,9),F(65,9),-2]
assert bern(p,0,1)==list(map(F,['50/9','71/27','19/9','2']))
assert bern(p,1,2)==list(map(F,['2','17/9','59/27','8/9']))
assert min(bern(p,0,1)+bern(p,1,2))>0
K=lambda e:e*(4-e)*(4+2*e)
U=lambda e:-F(29,9)*(5+e)**2+57*(5+e)-210
assert U(3)==F(358,9)<40 and 57-F(58,9)*8>0
assert K(2)+22-8==46 and K(3)+22-12==40
assert 3*2*(5+2)==42 and 19+2*2*(6+2)==51
print('final continuous intervals: PASS')
print('ALL WRITTEN INTERVAL CERTIFICATES PASS (optional exact algebra replay)')
