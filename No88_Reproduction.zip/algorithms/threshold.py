from closure import solve,broom,from_trace

def broom_shape(k,d):
    a=k//2;b=k-a
    tr=tuple((x,f) for x,f in ((1,((),)*a),(d-1,((),)*b)) if f)
    if d==2: tr=((1,((),)*k),) if k else ()
    return from_trace(d,tr)

for k in range(2,13):
    stop=max(3,2*k)
    # All positions and branch constraints stabilize from stop onward.
    while True:
        w,ss=solve(stop+k+1,stop,True)
        if w==broom(stop+k+1,stop) and ss=={broom_shape(k,stop)}: break
        stop*=2
    # Exact threshold for uniqueness at every subsequent diameter >=3.
    bad=[]; ties=[]
    for d in range(3,stop+1):
        n=d+k+1;w,ss=solve(n,d,True)
        if ss!={broom_shape(k,d)}:bad.append(d)
        if len(ss)>1:ties.append((d,len(ss)))
    threshold=max(bad,default=2)+1
    print('k',k,'tail_certificate_d',stop,'threshold_d',threshold,'non_broom_only_or_tie',bad,'ties',ties,flush=True)
