"""No.88 v0.6: exact optimizer and all extremizers as weighted skeletons.
Python 3.10+, NetworkX needed only for --test. No previous implementation imported.
"""
from functools import lru_cache
from math import comb
import argparse

def solve(n,d,all_shapes=False):
    if (n,d) in ((1,0),(2,1)):
        return n-1, ({()} if n==1 else {((1,()),)}) if all_shapes else None
    if not 2<=d<n: raise ValueError('infeasible n,d')
    k=n-d-1; H=min(k,d//2)
    q=lambda s:s*(n-s)
    F=[[0]+[None]*k for _ in range(H+1)]
    for h in range(1,H+1):
        for s in range(1,k+1):
            F[h][s]=max(q(t)+F[h-1][t-1]+F[h][s-t] for t in range(1,s+1) if F[h-1][t-1] is not None)
    X=sorted({0,d}|{x for h in range(1,H+1) for x in (h,d-h)})
    def gap(x,y,p):
        a=x+1+p; b=y+p
        return (b-a+1)*n*(a+b)//2-(b*(b+1)*(2*b+1)-(a-1)*a*(2*a-1))//6
    D=[{0:0}]
    for x,y in zip(X,X[1:]):
        h=min(x,d-x,H); nxt={}
        for p,v in D[-1].items():
            for s in range(k-p+1):
                if F[h][s] is None: continue
                z=p+s; val=v+F[h][s]+gap(x,y,z)
                if z not in nxt or val>nxt[z]: nxt[z]=val
        D.append(nxt)
    if not all_shapes: return D[-1][k],None
    @lru_cache(None)
    def forests(h,s):
        if s==0: return frozenset({()})
        if F[h][s] is None: return frozenset()
        out=set()
        for t in range(1,s+1):
            a=F[h-1][t-1]; b=F[h][s-t]
            if a is None or b is None or q(t)+a+b!=F[h][s]: continue
            for branch in forests(h-1,t-1):
                for rest in forests(h,s-t): out.add(tuple(sorted((branch,)+rest)))
        return frozenset(out)
    @lru_cache(None)
    def traces(i,z):
        if i==0: return frozenset({()}) if z==0 else frozenset()
        x,y=X[i-1:i+1]; h=min(x,d-x,H); out=set()
        for p,v in D[i-1].items():
            s=z-p
            if s<0 or F[h][s] is None or v+F[h][s]+gap(x,y,z)!=D[i][z]: continue
            for prefix in traces(i-1,p):
                for f in forests(h,s): out.add(prefix+(((x,f),) if f else ()))
        return frozenset(out)
    return D[-1][k],{from_trace(d,tr) for tr in traces(len(X)-1,k)}

def canonical(adj):
    # Degree-two vertices are suppressed, adding edge lengths exactly.
    adj={v:dict(ns) for v,ns in adj.items()}
    for v in list(adj):
        if len(adj[v])==2:
            (a,p),(b,q)=adj[v].items()
            del adj[a][v]; del adj[b][v]; del adj[v]
            adj[a][b]=adj[b][a]=p+q
    def root(v,p): return tuple(sorted((w,root(u,v)) for u,w in adj[v].items() if u!=p))
    return min(root(v,None) for v in adj)

def from_trace(d,tr):
    X=sorted({0,d}|{x for x,_ in tr}); adj={x:{} for x in X}; nxt=d+1
    def edge(a,b,w=1): adj[a][b]=adj[b][a]=w
    for x,y in zip(X,X[1:]): edge(x,y,y-x)
    def attach(x,f):
        nonlocal nxt
        for b in f:
            y=nxt; nxt+=1; adj[y]={}; edge(x,y); attach(y,b)
    for x,f in tr: attach(x,f)
    return canonical(adj)

def broom(n,d):
    k=n-d-1; a=k//2;b=k-a
    return comb(d+2,3)+k*(d*(d+1)//2+2)+2*(comb(a,2)+comb(b,2))+a*b*d

def test():
    import networkx as nx
    from time import perf_counter
    start=perf_counter();count=conditions=ext=0
    for n in range(3,17):
        best={}; shapes={}
        for t in nx.nonisomorphic_trees(n):
            ds=dict(nx.all_pairs_shortest_path_length(t));d=max(map(max,(r.values() for r in ds.values())));w=sum(sum(r.values()) for r in ds.values())//2; count+=1
            if w>=best.get(d,-1):
                if w>best.get(d,-1): best[d]=w;shapes[d]=set()
                shapes[d].add(canonical({v:{u:1 for u in t[v]} for v in t}))
        for d,w in best.items():
            value,got=solve(n,d,True)
            assert (value,got)==(w,shapes[d]),(n,d,value,w,len(got),len(shapes[d]))
            conditions+=1; ext+=len(got)
        print('BRUTE',n,count,conditions,ext,flush=True)
    print('ALL EXTREMIZER SETS PASS',count,conditions,ext,flush=True)
    for k in range(0,9):
        d=10**12; n=d+k+1; w,shapes=solve(n,d,True)
        assert w==broom(n,d) and len(shapes)==1,(k,w,len(shapes))
    print('GIANT FULL STRUCTURES PASS 9',flush=True)
    print('elapsed',perf_counter()-start,flush=True)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--test',action='store_true');p.add_argument('--n',type=int);p.add_argument('--d',type=int);p.add_argument('--all',action='store_true');a=p.parse_args()
    if a.test:test()
    else:print(solve(a.n,a.d,a.all))
