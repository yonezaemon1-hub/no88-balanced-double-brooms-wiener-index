from closure import solve,broom,from_trace

def nonbroom(n,d):
    """Max among compressed placements NOT representing balanced double broom; None if empty.
    This is not necessarily the second-best among *all* trees (nonextremal trees can have interior branches).
    """
    assert 3<=d<n
    k=n-d-1;H=min(k,d//2)
    if k==0:return None
    F=[[0]+[None]*k for _ in range(H+1)]
    for h in range(1,H+1):
        for s in range(1,k+1):
            F[h][s]=max(t*(n-t)+F[h-1][t-1]+F[h][s-t] for t in range(1,s+1) if F[h-1][t-1] is not None)
    X=sorted({0,d}|{x for h in range(1,H+1) for x in (h,d-h)})
    D={(0,False):0}
    for x,y in zip(X,X[1:]):
        h=min(x,d-x,H); nxt={}
        for (p,bad),v in D.items():
            for s in range(k-p+1):
                if F[h][s] is None:continue
                z=p+s; a=x+1+z;b=y+z
                G=n*(b-a+1)*(a+b)//2-(b*(b+1)*(2*b+1)-(a-1)*a*(2*a-1))//6
                flag=bad or (x==1 and s not in (k//2,(k+1)//2)) or (x not in (1,d-1) and s>0)
                key=(z,flag);score=v+F[h][s]+G
                if key not in nxt or score>nxt[key]:nxt[key]=score
        D=nxt
    assert D.get((k,False))==broom(n,d)
    return D.get((k,True))

def unique(k,d):
    b=nonbroom(k+d+1,d)
    return b is None or b<broom(k+d+1,d)

def threshold(k):
    if k<=1:return 3
    d0=max(3,2*k)
    # Every residual affine candidate is strictly dominated in slope unless broom.
    # At d0 the total contribution of pairs involving an extra vertex is <= U.
    U=d0*(k*(d0+1)+k*(k-1)//2)
    lo=d0;hi=d0+U+1
    assert unique(k,hi)
    if unique(k,d0):
        return max((d+1 for d in range(3,d0) if not unique(k,d)),default=3)
    while lo<hi:
        mid=(lo+hi)//2
        if unique(k,mid):hi=mid
        else:lo=mid+1
    return lo

if __name__=='__main__':
    num=0
    for k in range(13):
        for d in range(3, max(4,2*k+3)):
            n=k+d+1;w,ss=solve(n,d,True)
            a,b=k//2,(k+1)//2
            bs=from_trace(d,tuple((x,((),)*s) for x,s in ((1,a),(d-1,b)) if s))
            assert unique(k,d)==(ss=={bs}),(k,d,len(ss))
            num+=1
        print('threshold',k,threshold(k),flush=True)
    print('UNIQUENESS SET CROSSCHECK PASS',num,flush=True)
