from pathlib import Path
import hashlib, subprocess, sys, re
root=Path(__file__).resolve().parent
for line in (root/'SHA256SUMS.txt').read_text(encoding='ascii').splitlines():
    digest,name=line.split('  ',1)
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest, name
print('SOURCE SHA256 PASS')
def normalized(s):
    return '\n'.join(x for x in s.splitlines() if not x.startswith('elapsed ')).strip()
for folder,script,args,log in [
 ('threshold_proof','check.py',[],'check.log'),
 ('threshold_proof','crosscheck.py',[],'crosscheck.log'),
 ('boundary','cut_audit.py',[],'cut_audit.log'),
 ('algorithms','closure.py',['--test'],'test.log'),
 ('algorithms','threshold.py',[],'threshold.log'),
 ('algorithms','uniqueness.py',[],'uniqueness.log')]:
    p=subprocess.run([sys.executable,'-B',script,*args],cwd=root/folder,capture_output=True,text=True,encoding='utf-8')
    if p.returncode or normalized(p.stdout)!=normalized((root/folder/log).read_text(encoding='utf-8')):
        print(p.stdout,p.stderr);raise SystemExit('REPLAY FAIL '+script)
    print('BASELINE PASS '+folder+'/'+script)
print('NO88 PUBLIC FULL REPLAY PASS')
